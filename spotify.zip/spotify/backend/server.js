const path    = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const express = require('express');
const cors    = require('cors');
const path    = require('path');

const app = express();

// ─── Middleware ────────────────────────────────
app.use(cors({ origin: '*', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, '..')));

// ─── Routes ───────────────────────────────────
app.use('/api/auth',      require('./routes/auth'));
app.use('/api/playlists', require('./routes/playlists'));
app.use('/api/songs',     require('./routes/songs'));

// ─── Health check ─────────────────────────────
app.get('/api/health', (req, res) => {
    res.json({ success: true, message: 'Spotify Clone API is running 🎵', time: new Date() });
});

// ─── Catch-all: serve frontend ────────────────
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// ─── Error handler ────────────────────────────
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ success: false, message: 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`\n🎵  Spotify Clone Server running on http://localhost:${PORT}`);
    console.log(`📡  API:       http://localhost:${PORT}/api/health`);
    console.log(`🌐  Frontend:  http://localhost:${PORT}\n`);
});
