const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
    host:     process.env.DB_HOST     || 'localhost',
    user:     process.env.DB_USER     || 'root',
    password: process.env.DB_PASSWORD || '12345678',
    database: process.env.DB_NAME     || 'spotify_clone',
    waitForConnections: true,
    connectionLimit:    10,
    queueLimit:         0,
    decimalNumbers:     true,
});

// Test connection on startup
pool.getConnection()
    .then(conn => {
        console.log('✅  MySQL connected successfully');
        conn.release();
    })
    .catch(err => {
        console.error('❌  MySQL connection failed:', err.message);
    });

module.exports = pool;
